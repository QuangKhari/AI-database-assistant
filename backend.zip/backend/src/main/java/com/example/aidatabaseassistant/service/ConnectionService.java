package com.example.aidatabaseassistant.service;

import com.example.aidatabaseassistant.config.EncryptionUtil;
import com.example.aidatabaseassistant.dto.ConnectionRequest;
import com.example.aidatabaseassistant.dto.ConnectionResponse;
import com.example.aidatabaseassistant.dto.ConnectionUpdateRequest;
import com.example.aidatabaseassistant.entity.DatabaseConnection;
import com.example.aidatabaseassistant.entity.User;
import com.example.aidatabaseassistant.repository.DatabaseConnectionRepository;
import com.example.aidatabaseassistant.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.example.aidatabaseassistant.security.SsrfProtection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ConnectionService {

    private final DatabaseConnectionRepository connectionRepository;
    private final UserRepository userRepository;
    private final EncryptionUtil encryptionUtil;
    private final SsrfProtection ssrfProtection;
    private static final int CONNECT_TIMEOUT_MS = 5000;
    private static final int SOCKET_TIMEOUT_MS = 10000;

    // Khong khai bao "final" vi day la field duoc inject bang @Value (field
    // injection), tach biet voi cac dependency con lai dang duoc constructor-inject
    // qua @RequiredArgsConstructor. Neu de "final" thi Lombok se doi hoi truyen
    // gia tri nay qua constructor -> pha vo constructor 4-tham-so hien tai dang
    // duoc goi truc tiep trong ConnectionServiceTest.
    @Value("${connection.max-per-user:5}")
    private int maxConnectionsPerUser = 5;

    public boolean testConnection(ConnectionRequest request) {
        ssrfProtection.validateHost(request.getHost());

        String url = buildJdbcUrl(
                request.getDbType(),
                request.getHost(),
                request.getPort(),
                request.getDatabaseName()
        );

        try (Connection conn = DriverManager.getConnection(
                url,
                request.getUsername(),
                request.getPassword())) {

            return conn.isValid(3);

        } catch (SQLException e) {
            return false;
        }
    }

    public ConnectionResponse saveConnection(String username, ConnectionRequest request) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy user"));

        // SSRF guard: truoc day chi testConnection() goi validateHost(), nen
        // saveConnection() co the luu thang mot host noi bo (vi du 127.0.0.1,
        // 169.254.169.254 - metadata endpoint cua cloud...) ma khong bi chan,
        // roi sau nay reconnect()/updateConnection() van vo tu ket noi toi do.
        ssrfProtection.validateHost(request.getHost());

        long currentCount = connectionRepository.countByUserId(user.getId());
        if (currentCount >= maxConnectionsPerUser) {
            throw new IllegalArgumentException(
                    "Bạn đã đạt giới hạn tối đa " + maxConnectionsPerUser + " kết nối database. "
                            + "Vui lòng xóa bớt kết nối cũ trước khi thêm mới.");
        }

        DatabaseConnection connection = DatabaseConnection.builder()
                .user(user)
                .name(request.getName())
                .dbType(request.getDbType())
                .host(request.getHost())
                .port(request.getPort())
                .databaseName(request.getDatabaseName())
                .username(request.getUsername())
                .encryptedPassword(encryptionUtil.encrypt(request.getPassword()))
                .build();

        connectionRepository.save(connection);
        return toResponse(connection);
    }

    public List<ConnectionResponse> getConnectionsByUser(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy user"));

        return connectionRepository.findByUserId(user.getId())
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }



    private String buildJdbcUrl(String dbType, String host, Integer port, String databaseName) {
        if ("mysql".equalsIgnoreCase(dbType)) {
            return "jdbc:mysql://" + host + ":" + port + "/" + databaseName
                    + "?connectTimeout=" + CONNECT_TIMEOUT_MS
                    + "&socketTimeout=" + SOCKET_TIMEOUT_MS;
        }
        throw new IllegalArgumentException("Loại database chưa được hỗ trợ: " + dbType);
    }

    private ConnectionResponse toResponse(DatabaseConnection connection) {
        return new ConnectionResponse(
                connection.getId(),
                connection.getName(),
                connection.getDbType(),
                connection.getHost(),
                connection.getPort(),
                connection.getDatabaseName(),
                connection.getUsername()
        );
    }

    public ConnectionResponse getConnection(String username, Long connectionId) {
        DatabaseConnection connection = getOwnedConnection(username, connectionId);
        return toResponse(connection);
    }

    public ConnectionResponse updateConnection(String username, Long connectionId, ConnectionUpdateRequest request) {
        DatabaseConnection connection = getOwnedConnection(username, connectionId);

        // Ownership check (getOwnedConnection) phai chay TRUOC de IDOR test
        // (updateConnection_shouldThrow_whenRequestedByNonOwner_IDOR) khong bi
        // anh huong boi loi validate host. Sau khi xac nhan la chu so huu, host
        // moi van phai duoc kiem tra SSRF vi user co the doi host sang dia chi
        // noi bo trong luc update.
        ssrfProtection.validateHost(request.getHost());

        connection.setName(request.getName());
        connection.setHost(request.getHost());
        connection.setPort(request.getPort());
        connection.setDatabaseName(request.getDatabaseName());
        connection.setUsername(request.getUsername());

        if (request.getPassword() != null && !request.getPassword().isBlank()) {
            connection.setEncryptedPassword(encryptionUtil.encrypt(request.getPassword()));
        }

        connectionRepository.save(connection);
        return toResponse(connection);
    }

    public boolean reconnect(String username, Long connectionId) {
        DatabaseConnection connection = getOwnedConnection(username, connectionId);

        ssrfProtection.validateHost(connection.getHost());

        String rawPassword = encryptionUtil.decrypt(connection.getEncryptedPassword());

        String url = buildJdbcUrl(connection.getDbType(), connection.getHost(),
                connection.getPort(), connection.getDatabaseName());

        try (Connection conn = DriverManager.getConnection(url, connection.getUsername(), rawPassword)) {
            return conn.isValid(3);
        } catch (SQLException e) {
            return false;
        }
    }

    public void disconnect(String username, Long connectionId) {
        DatabaseConnection connection = getOwnedConnection(username, connectionId);
        connectionRepository.delete(connection);
    }

    private DatabaseConnection getOwnedConnection(String username, Long connectionId) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy user"));

        DatabaseConnection connection = connectionRepository.findById(connectionId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy connection"));

        if (!connection.getUser().getId().equals(user.getId())) {
            throw new IllegalArgumentException("Bạn không có quyền truy cập connection này");
        }

        return connection;
    }
}